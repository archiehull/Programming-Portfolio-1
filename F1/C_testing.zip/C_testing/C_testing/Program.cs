﻿using System;

namespace myNamespace
{
    class myClass
    {
        static void Main()
        {
            Console.WriteLine("Hello, World");
        }
    }
}